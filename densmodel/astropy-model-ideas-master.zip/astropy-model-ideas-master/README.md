# astropy-model-ideas
Ideas and examples related to integrating astropy modeling with other fitting packages
