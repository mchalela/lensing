import sys
import time
import numpy as np
import pandas as pd
import lenscat
from astropy.io import fits
from astropy.table import Table
from astropy.cosmology import LambdaCDM

cosmo = LambdaCDM(H0=70, Om0=0.3, Ode0=0.7)


with fits.open('redmapper_dr8_public_v6.3_catalog.fits') as f:
	lensname='redMapper'
	ft = Table(f[1].data)
	cols = ['ID','RA','DEC','Z_LAMBDA','Z_LAMBDA_ERR','LAMBDA','LAMBDA_ERR']
	df = ft[cols].to_pandas()

t0 = time.time()
print '*** CS82 ***'
# Search neighbors around each lens
R_deg = lenscat.Mpc2deg(R_Mpc=10., z=df['Z_LAMBDA'], cosmo=cosmo)
cs82_cat=lenscat.CS82.bubble_neighbors(centre=df[['RA','DEC']], radii=R_deg, append_data=df)

mask = cs82_cat.data['Z_B']>cs82_cat.data['Z_LAMBDA']
cs82_cat.data = cs82_cat.data[mask]
print 'Tiempo', (time.time() - t0)/60.

print 'Distances...'
# Compute distances
DL = np.array(cosmo.angular_diameter_distance(cs82_cat.data['Z_LAMBDA']))
DS = np.array(cosmo.angular_diameter_distance(cs82_cat.data['Z_B']))
DLS= np.array(cosmo.angular_diameter_distance_z1z2(cs82_cat.data['Z_LAMBDA'], cs82_cat.data['Z_B']))
index = cs82_cat.data.columns.get_loc('ID')
cs82_cat.add_column(index=index, name='DLS', data=DLS)
cs82_cat.add_column(index=index, name='DL', data=DL)
cs82_cat.add_column(index=index, name='DS', data=DS)

cs82_cat.write_to('gx_'+cs82_cat.name+'_'+lensname+'.fits')
print 'Tiempo', (time.time() - t0)/60.

#####################################################################################################
t0 = time.time()
print '*** KiDS ***'
# Search neighbors around each lens
R_deg = lenscat.Mpc2deg(R_Mpc=10., z=df['Z_LAMBDA'], cosmo=cosmo)
kids_cat=lenscat.KiDS.bubble_neighbors(centre=df[['RA','DEC']], radii=R_deg, append_data=df)

mask = kids_cat.data['Z_B']>kids_cat.data['Z_LAMBDA']
kids_cat.data = kids_cat.data[mask]
print 'Tiempo', (time.time() - t0)/60.

print 'Distances...'
# Compute distances
DL = np.array(cosmo.angular_diameter_distance(kids_cat.data['Z_LAMBDA']))
DS = np.array(cosmo.angular_diameter_distance(kids_cat.data['Z_B']))
DLS= np.array(cosmo.angular_diameter_distance_z1z2(kids_cat.data['Z_LAMBDA'],kids_cat.data['Z_B']))
index = kids_cat.data.columns.get_loc('ID')
kids_cat.add_column(index=index, name='DLS', data=DLS)
kids_cat.add_column(index=index, name='DL', data=DL)
kids_cat.add_column(index=index, name='DS', data=DS)

kids_cat.write_to('gx_'+kids_cat.name+'_'+lensname+'.fits')
print 'Tiempo', (time.time() - t0)/60.

#####################################################################################################
t0 = time.time()
print '*** CFHT ***'
# Search neighbors around each lens
R_deg = lenscat.Mpc2deg(R_Mpc=10., z=df['Z_LAMBDA'], cosmo=cosmo)
cfht_cat=lenscat.CFHT.bubble_neighbors(centre=df[['RA','DEC']], radii=R_deg, append_data=df)

mask = cfht_cat.data['Z_B']>cfht_cat.data['Z_LAMBDA']
cfht_cat.data = cfht_cat.data[mask]
print 'Tiempo', (time.time() - t0)/60.

print 'Distances...'
# Compute distances
DL = np.array(cosmo.angular_diameter_distance(cfht_cat.data['Z_LAMBDA']))
DS = np.array(cosmo.angular_diameter_distance(cfht_cat.data['Z_B']))
DLS= np.array(cosmo.angular_diameter_distance_z1z2(cfht_cat.data['Z_LAMBDA'],cfht_cat.data['Z_B']))
index = cfht_cat.data.columns.get_loc('ID')
cfht_cat.add_column(index=index, name='DLS', data=DLS)
cfht_cat.add_column(index=index, name='DL', data=DL)
cfht_cat.add_column(index=index, name='DS', data=DS)

cfht_cat.write_to('gx_'+cfht_cat.name+'_'+lensname+'.fits')
print 'Tiempo', (time.time() - t0)/60.