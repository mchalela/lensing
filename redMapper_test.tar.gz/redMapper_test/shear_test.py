import sys
import numpy as np
import matplotlib.pyplot as plt ; plt.ion()
from astropy.io import fits
from lensing import gentools, shear, lenscat
from astropy.cosmology import LambdaCDM
cosmo = LambdaCDM(H0=70, Om0=0.3, Ode0=0.7)


kids_cat = lenscat.Catalog.read_catalog('gx_KiDS_redMapper.fits')
cfht_cat = lenscat.Catalog.read_catalog('gx_CFHT_redMapper.fits')
cs82_cat = lenscat.Catalog.read_catalog('gx_CS82_redMapper.fits')
mALFA0 = cs82_cat.data['RA']>275
cs82_cat.data['RA'][mALFA0] -= 360.
mALFA0 = cs82_cat.data['RAJ2000']>275
cs82_cat.data['RAJ2000'][mALFA0] -= 360.
#cfht_cat.data['e2'] -= cfht_cat.data['c2']
#cfht_cat.remove_column(columns='c2')

cat = cs82_cat + kids_cat + cfht_cat
#cat = cat + cfht_cat
#cat = cs82_cat
#cat = kids_cat
#cat = cfht_cat

print '---- FILTRAR -------'
delta_z = 0.1
odds_min = 0.5
zback_max = 100.
l_min = 39.7
l_max = 145.
z_min = 0.1
z_max = 0.33

mask_back = (cat.data['Z_B']>(cat.data['Z_LAMBDA']+delta_z)) * (cat.data['ODDS']>=odds_min)
mask_back *= (cat.data['Z_B']<zback_max) #* (cat.data['Z_B']>(cat.data['Z_LAMBDA']+cat.data['BPZ_LOW95']/2.))
mask_lens = (cat.data['LAMBDA']>=l_min) * (cat.data['LAMBDA']<l_max)
mask_lens *= (cat.data['Z_LAMBDA']>=z_min) * (cat.data['Z_LAMBDA']<z_max)
mask = mask_back * mask_lens

profile = shear.Profile(cat.data[mask], rin_hMpc=0.1, rout_hMpc=10., bins=30, boot_flag=True)

# Header..
header = {'delta_z': delta_z, 'odds_min': odds_min, 'zback_max': zback_max, 
			'l_min': l_min, 'l_max': l_max, 'z_min': z_min, 'z_max': z_max}
#profile.write_to('redMapper_CS82.profile', header=header, overwrite=True)
#profile.write_to('redMapper_CFHT.profile', header=header, overwrite=True)
#profile.write_to('redMapper_KiDS.profile', header=header, overwrite=True)
profile.write_to('redMapper_COMB_30bin.profile', header=header, overwrite=True)



plt.figure()
plt.plot(profile.r_hMpc, profile.shear, 'ko', label='Combined')
plt.errorbar(profile.r_hMpc, profile.shear, yerr=profile.shear_error, fmt='None', ecolor='k')

#plt.plot(pcs82.r_Mpc*cosmo.h, pcs82.shear*pcs82.r_Mpc*cosmo.h, 'ko', label='CS82')
#plt.errorbar(pcs82.r_Mpc*cosmo.h, pcs82.shear*pcs82.r_Mpc*cosmo.h, yerr=pcs82.stat_error*pcs82.r_Mpc*cosmo.h, fmt='None', ecolor='k')

#plt.plot(pkids.r_Mpc*cosmo.h, pkids.shear*pkids.r_Mpc*cosmo.h, 'mo', label='KiDS')
#plt.errorbar(pkids.r_Mpc*cosmo.h, pkids.shear*pkids.r_Mpc*cosmo.h, yerr=pkids.stat_error*pkids.r_Mpc*cosmo.h, fmt='None', ecolor='m')

#plt.plot(pcfht.r_Mpc*cosmo.h, pcfht.shear*pcfht.r_Mpc*cosmo.h, 'go', label='CFHT')
#plt.errorbar(pcfht.r_Mpc*cosmo.h, pcfht.shear*pcfht.r_Mpc*cosmo.h, yerr=pcfht.stat_error*pcfht.r_Mpc*cosmo.h, fmt='None', ecolor='g')

plt.ylim([1.,400.])
plt.xlim([0.1,10])
plt.loglog()
plt.legend()
plt.ylabel(u'$\Delta\Sigma [M_{\odot}\,pc^{-2}]$',fontsize=15)
plt.xlabel('r [$h^{-1}\,$Mpc]',fontsize=15)
#plt.plot(profile3.r_Mpc*cosmo.h, profile3.cero, 'kx')
#plt.errorbar(profile3.r_Mpc*cosmo.h, profile3.cero, yerr=profile3.stat_error, fmt='None', ecolor='k')
